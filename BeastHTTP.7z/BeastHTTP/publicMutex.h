#pragma once


#include "publicHeader.h"

struct publicMutex
{
	publicMutex() = default;

	mutex m1;
};